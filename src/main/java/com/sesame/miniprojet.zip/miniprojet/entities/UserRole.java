package com.sesame.miniprojet.entities;

public enum UserRole {admin,member
}
