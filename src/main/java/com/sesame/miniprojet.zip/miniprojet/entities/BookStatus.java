package com.sesame.miniprojet.entities;

public enum BookStatus {
    AVAILABLE,
    BORROWED
}
